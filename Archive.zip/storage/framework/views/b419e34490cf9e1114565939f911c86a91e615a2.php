<div class="header">
    <div class="userinfo_block">Hi <?php echo e(Auth::user()->name); ?></div>
    <div class="logout_block"><a href="<?php echo e(url('logout')); ?>">Logout</a></div>
</div>
