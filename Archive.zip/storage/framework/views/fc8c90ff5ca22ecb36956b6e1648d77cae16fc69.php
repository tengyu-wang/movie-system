<!DOCTYPE html>
<html>
    <head>
        <?php echo $__env->make('head', ['pageTitle' => 'Movies'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <?php if(isset($ERROR)): ?> <script>alert('<?php echo e($ERROR); ?>');</script> <?php endif; ?>
        <div class="main-column">
        <?php if(!isset(Auth::user()->email)): ?>
            <script>window.location = 'login';</script>
        <?php else: ?>
            <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

            <div id="genre-list-block" class="sidebar">
                <div id="search-block">
                    <label for="search-query">Search movies:</label>
                    <div class="search-input-block">
                        <input type="text" id="search-query" value="" />
                        <a id="search-button" tabindex="0" href="#"><img class="search-icon" src="<?php echo e(URL::asset('images/search_icon.png')); ?>" /></a>
                    </div>
                </div>
        <?php if(isset($genreList)): ?>
            <?php $__currentLoopData = $genreList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="genre-row <?php if($index === 0): ?> first-child <?php endif; ?>">
                    <input type="hidden" class="genre-id-holder" value="<?php echo e($genre['id']); ?>">
                    <?php echo e($genre['name']); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
            </div>

            <div class="content-block">
                <div id="genre-movie-list-block"></div>
            </div>

            <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>

        <script>
            $(function($) {
                $('.genre-row').click(function() {
                    $('.genre-row').removeClass('select');
                    $(this).addClass('select');
                    var genreId = $(this).find('.genre-id-holder').first().val();

                    var moverSeeker = new MovieSeeker({
                        "searchParameters": {"genreId": genreId, "query": undefined},
                        "url": "<?php echo e(url("get-genre-movies")); ?>",
                        "movieUrl": "<?php echo e(url("get-movie")); ?>",
                        "token": "<?php echo e(csrf_token()); ?>",
                        "posterPathPrefix": "<?php echo e($imageUrlPrefix); ?>"
                    });

                    moverSeeker.generateMovieList();
                });

                $('input#search-query').focus(function() {
                    $(this).parent().animate({
                        width: "300px"
                    }, 300);

                    $(this).animate({
                        width: "266px"
                    }, 300);
                }).blur(function() {
                    $(this).animate({
                        width: "76px"
                    }, 300);

                    $(this).parent().animate({
                        width: "110px"
                    }, 300);
                });

                $('a#search-button').focus(function() {
                    $(this).blur(); // prevent multiple focus event for this

                    $('.genre-row').removeClass('select');

                    if ($.trim($('input#search-query').val()).length < 2) {
                        alert('Please enter at least two chars!');
                        return false;
                    }

                    var moverSeeker = new MovieSeeker({
                        "searchParameters": {"genreId": undefined, "query": $.trim($('input#search-query').val())},
                        "url": "<?php echo e(url("get-searched-movies")); ?>",
                        "movieUrl": "<?php echo e(url("get-movie")); ?>",
                        "token": "<?php echo e(csrf_token()); ?>",
                        "posterPathPrefix": "<?php echo e($imageUrlPrefix); ?>"
                    });

                    moverSeeker.generateMovieList();
                });

                $('.genre-row.first-child').trigger('click');
            });

        </script>
    </body>
</html>

