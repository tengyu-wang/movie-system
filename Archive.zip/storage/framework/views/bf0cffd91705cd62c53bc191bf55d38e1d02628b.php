<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('head', ['pageTitle' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php if(isset(Auth::user()->email)): ?>
        <script>window.location = 'movies';</script>
    <?php endif; ?>

    <div class="container box">
        <h1>Movie City System</h1>
        <?php if($message = Session::get('error')): ?>
            <div class="alert-box">
                <ul>
                    <li><?php echo e($message); ?></li>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(count($errors) > 0): ?>
            <div class="alert-box">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('/login/check')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control"/>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control"/>
            </div>
            <div class="form-group">
                <input type="submit" name="login" value="Login" class="btn btn-primary"/>
            </div>
        </form>
    </div>
</body>
</html>

