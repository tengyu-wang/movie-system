<div class="movie-details-block">
<?php if(isset($ERROR)): ?>
    <div class="no-movies-message"><?php echo e($ERROR); ?></div>
<?php else: ?>
    <div class="poster-medium">
        <?php if(empty($movie['poster_path'])): ?>
        <img src="/images/no_poster_icon.png" />
        <?php elseif(empty($movie['backdrop_path'])): ?>
        <img src="<?php echo e($imageUrlPrefix); ?><?php echo e($movie['poster_path']); ?>" />
        <?php else: ?>
        <div class="flip-container">
            <div class="flipper">
                <div class="front">
                    <img src="<?php echo e($imageUrlPrefix); ?><?php echo e($movie['poster_path']); ?>" />
                </div>
                <div class="back">
                    <img src="<?php echo e($imageUrlPrefix); ?><?php echo e($movie['backdrop_path']); ?>" />
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="movie-info">
        <div id="movie-title">
            <?php echo e($movie['title']); ?> <?php if($movie['release_date']): ?>(<?php echo e(substr($movie['release_date'], 0, 4)); ?>) <?php endif; ?>
        </div>
        <div id="release-date">
            Release date: <?php if($movie['release_date']): ?> <I><?php echo e(date('j', strtotime($movie['release_date']))); ?> <sup><?php echo e(date('S', strtotime($movie['release_date']))); ?></sup><?php echo e(date(' F, Y', strtotime($movie['release_date']))); ?></I> <?php endif; ?>
        </div>
        <div id="language">
            Language: <?php if(!empty($movie['spoken_languages'])): ?> <I><?php echo e(implode(', ', array_column($movie['spoken_languages'], 'name'))); ?></I> <?php endif; ?>
        </div>
        <div id="rate">Rate: <?php if($movie['vote_average']): ?> <I><?php echo e($movie['vote_average']); ?></I> <?php endif; ?> </div>
        <div id="overview-title">Overview: </div>
        <div id="overview-content"> <?php if($movie['overview']): ?> <I><?php echo e($movie['overview']); ?></I> <?php endif; ?> </div>
    </div>
<?php endif; ?>
</div>
