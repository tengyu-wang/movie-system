<div class="footer">
    <div>@ 2019 Movie City&trade; | Email: tengyu.wang0511@gmail.com</div>
</div>
